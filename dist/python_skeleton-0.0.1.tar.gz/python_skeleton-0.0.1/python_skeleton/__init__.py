# MODULES
from . import __demo__



# STRUCTURE
plugins = {
"__demo__" : __demo__.__dir__(),
}