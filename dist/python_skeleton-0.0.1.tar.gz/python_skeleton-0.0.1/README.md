# python_skeleton
Cookie-Cutter Project

# New File
```
nano project.py
```
# Code (URL)
[COPY-ME](https://raw.githubusercontent.com/hlop3z/python_skeleton/master/project.py)

# run
```
python3.7 project.py myapp
```
